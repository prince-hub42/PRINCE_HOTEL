// Room prices
const roomPrices = {
  single: 1000,
  double: 1800,
  deluxe: 2500
};

// Food menu
const menuItems = [
  { name: "Paneer Tikka", price: 150 },
  { name: "Veg Biryani", price: 120 },
  { name: "Butter Naan", price: 30 },
  { name: "Masala Dosa", price: 80 }
];

// Load food menu on page load
window.onload = function () {
  const menuDiv = document.getElementById("menu");
  menuItems.forEach((item, index) => {
    menuDiv.innerHTML += `
      <div>
        <label>${item.name} - ₹${item.price}</label>
        <input type="number" id="food${index}" placeholder="Qty" min="0" value="0" />
      </div>
    `;
  });
};

function calculateTotal() {
  // Room calculation
  const roomType = document.getElementById("roomType").value;
  const nights = parseInt(document.getElementById("nights").value);
  const roomCost = roomPrices[roomType] * nights;

  // Food calculation
  let foodCost = 0;
  menuItems.forEach((item, index) => {
    const qty = parseInt(document.getElementById(`food${index}`).value) || 0;
    foodCost += item.price * qty;
  });

  const total = roomCost + foodCost;

  // Show bill
  document.getElementById("billOutput").innerHTML = `
    <h3>Bill Summary</h3>
    <p>Room Cost: ₹${roomCost}</p>
    <p>Food Cost: ₹${foodCost}</p>
    <p><strong>Total Amount: ₹${total}</strong></p>
  `;

  // Show QR
  document.getElementById("qrSection").style.display = "block";
  document.getElementById("payAmount").innerText = "Please pay ₹" + total + " via UPI QR code";
}
